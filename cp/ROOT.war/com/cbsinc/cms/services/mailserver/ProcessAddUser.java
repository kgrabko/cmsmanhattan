package com.cbsinc.cms.services.mailserver;

/**
 * <p>
 * Title: Content Manager System
 * </p>
 * <p>
 * Description: System building web application develop by Konstantin Grabko.
 * Konstantin Grabko is Owner and author this code.
 * Программный код написан Грабко Константином Владимировичем и является его интеллектуальной 
 * собственностью.
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: Grabko Business (Предприниматель Грабко Константин Владимирович)  
 * </p>
 * 
 * @author Konstantin Grabko
 * @version 1.0
 */


public class ProcessAddUser   {
	
	
	   public static void main(String[] args) 
	   {
		
		   AddUserInMail mailSettingsSession = new AddUserInMail();
		   //mailSettingsSession.exec("root" ,"root"  ,"leha177" , "leha177" );
		   //mailSettingsSession.exec("root" ,"root"  ,"leha277" , "leha277" );
	   }
	   
	
}
