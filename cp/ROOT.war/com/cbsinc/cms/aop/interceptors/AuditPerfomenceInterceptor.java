package com.cbsinc.cms.aop.interceptors;

/**
 * <p>
 * Title: Content Manager System
 * </p>
 * <p>
 * Description: System building web application develop by Konstantin Grabko.
 * Konstantin Grabko is Owner and author this code. You can not use it and you
 * cannot change it without written permission from Konstantin Grabko Email:
 * konstantin.grabko@yahoo.com or konstantin.grabko@gmail.com
 * </p>
 * <p>
 * Copyright: Copyright (c) 2002-2014
 * </p>
 * <p>
 * Company: CENTER BUSINESS SOLUTIONS INC
 * </p>
 * 
 * @author Konstantin Grabko
 * @version 1.0
 */

//import javax.interceptor.AroundInvoke;
//import javax.interceptor.InvocationContext;

public class AuditPerfomenceInterceptor {

//	@AroundInvoke
//    public Object audit(InvocationContext invocation) throws Exception{
//		AuditPerfomence audit = invocation.getMethod().getAnnotation(AuditPerfomence.class);
//        //AuditWarning warn = invocation.getMethod().getDeclaringClass().getAnnotation(AuditWarning.class);
//        Object obj = null;
//        try{
//            obj = invocation.proceed();
//            return obj;
//        }catch(Exception ex){
//            obj = ex;
//            throw ex;
//        }
//        finally
//        {
//           
//        	System.out.println(" call interceptor ! ");
//        	//if(((obj instanceof EJBAccessException) || (obj instanceof LoginException)) ){
//            //}
//            //else if(audit != null && !(obj instanceof Exception))
//            //{
//                //strategy = audit.strategy().getStrategy();
//                //strategy.process(invocation, audit.code().getCode(), principal);
//           // }
//        	}
//    	}

}
