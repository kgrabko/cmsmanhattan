package com.cbsinc.cms.jms.controllers;

public abstract class AbstractMessageBean  implements MessageListener
{


	
}
