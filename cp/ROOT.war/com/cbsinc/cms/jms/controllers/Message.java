package com.cbsinc.cms.jms.controllers;

import java.util.HashMap;

public class Message extends HashMap {

}
