package com.cbsinc.cms.dto;

public class News {
	
String pageUrl;
String productId;
String name;
String fileExist;
String icon;
String image;
String bigImageType;
String iconType;
String userId;
String policyUrl;
String description;
String amount;
Currency currency; 
String statistic;
String version;
String cdate;
String creatorInfoUserId;

}
