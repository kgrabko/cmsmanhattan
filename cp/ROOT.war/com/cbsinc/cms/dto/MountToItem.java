package com.cbsinc.cms.dto;

public class MountToItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
