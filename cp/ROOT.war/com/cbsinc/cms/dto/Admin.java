package com.cbsinc.cms.dto;

public class Admin {

	String postManager;
	String postManagerImg;
	String postManagerText;

	public String getPostManager() {
		return postManager;
	}

	public void setPostManager(String postManager) {
		this.postManager = postManager;
	}

	public String getPostManagerImg() {
		return postManagerImg;
	}

	public void setPostManagerImg(String postManagerImg) {
		this.postManagerImg = postManagerImg;
	}

	public String getPostManagerText() {
		return postManagerText;
	}

	public void setPostManagerText(String postManagerText) {
		this.postManagerText = postManagerText;
	}

}
