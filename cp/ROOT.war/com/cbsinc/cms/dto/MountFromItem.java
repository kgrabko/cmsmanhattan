package com.cbsinc.cms.dto;

public class MountFromItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
