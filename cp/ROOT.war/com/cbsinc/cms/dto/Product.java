package com.cbsinc.cms.dto;

public class Product {
	
String productId;
String rowId;
String name;
String typeId;
String icon;
String image;
String userId;
String policyUrl;
String description;
String amount;
Currency currency;
String version;
String creteria1;
String creteria2;
String creteria3;
String creteria4;
String creteria5;
String creteria6;
String creteria7;
String creteria8;
String creteria9;
String creteria10;
String color;

}
