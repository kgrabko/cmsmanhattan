package com.cbsinc.cms.dto;

public class Currency {
	
	 String code ;
     String description;

}
