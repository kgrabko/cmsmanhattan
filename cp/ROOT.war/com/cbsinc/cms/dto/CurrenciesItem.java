package com.cbsinc.cms.dto;

public class CurrenciesItem {
	
	String selected ;
	String item ;
	String code;
	String url;

}
