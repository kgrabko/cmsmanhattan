package com.cbsinc.cms.dto;

public class ProductBlog {
	
String productId;
String rowId;
String fileExist ;
String name;
String parentTitle;
String productParentId;
String icon;
String image;
String userId;
String author;
String company;
String policyUrl;
String description;
String amount;
Currency currency;
String version;
String statistic;
String cdate;

}
