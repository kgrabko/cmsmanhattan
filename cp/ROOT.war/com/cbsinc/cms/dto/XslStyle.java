package com.cbsinc.cms.dto;

public class XslStyle {
	
	String xsl_url;
    String  xsl_url_text;

}
