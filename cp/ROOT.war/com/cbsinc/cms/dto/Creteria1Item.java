package com.cbsinc.cms.dto;

public class Creteria1Item {
	
	String selected;
	String item;
	String code ;
	String url ;

}
