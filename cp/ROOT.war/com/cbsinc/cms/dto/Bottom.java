package com.cbsinc.cms.dto;

public class Bottom {
	
	String productId ;
	String rowId;
	String fileExist;
	String name;
	String icon;
	String image;
	String bigImageType;
	String iconType;
	String userId;
	String policyUrl;
	String productUrl;
	String description;
	String amount;
	Currency currency;
	String version;

}
