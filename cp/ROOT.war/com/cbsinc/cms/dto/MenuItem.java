package com.cbsinc.cms.dto;

public class MenuItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
