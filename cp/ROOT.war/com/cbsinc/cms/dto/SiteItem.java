package com.cbsinc.cms.dto;

public class SiteItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
