package com.cbsinc.cms.dto;

public class DayFromItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
