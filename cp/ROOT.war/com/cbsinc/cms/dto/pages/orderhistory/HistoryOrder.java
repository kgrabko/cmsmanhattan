package com.cbsinc.cms.dto.pages.orderhistory;

public class HistoryOrder {
	
	String order_id; 
	String end_amount;
	String cdate;
	String paystatus_id;
	String paystatus_lable;
	String currency_lable;

}
