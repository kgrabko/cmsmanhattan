package com.cbsinc.cms.dto.pages.order;

import com.cbsinc.cms.dto.Currency;

public class ProductInCart {
	
	String basket_id;
	String policy_url;
	String page_url ;
	String product_id ;
	String name ; 
	String file_exist ;
	String icon ; 
	String image ;
	String image_type;
	String product_url ;
	String back_url ;
	String description ;
	String amount ;
	Currency currency ;
	String statistic ;  
	String cdate ;  
	String creator_info_user_id ;

}
