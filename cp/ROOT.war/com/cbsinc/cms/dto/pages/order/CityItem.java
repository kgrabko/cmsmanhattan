package com.cbsinc.cms.dto.pages.order;

public class CityItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
