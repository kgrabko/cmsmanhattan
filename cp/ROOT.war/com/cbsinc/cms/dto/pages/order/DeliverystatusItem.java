package com.cbsinc.cms.dto.pages.order;

public class DeliverystatusItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
