package com.cbsinc.cms.dto.pages.order;

public class PaystatusItem {

	String selected;
	String item;
	String code;
	String url;

}
