package com.cbsinc.cms.dto.pages.description;

import com.cbsinc.cms.dto.Currency;

public class ProductDescription {
	
	String page_url ;
	String product_id ;
	String name ; 
	String file_exist ;
	String icon ; 
	String image ;
	String image_type;
	String product_url ;
	String back_url ;
	String description ;
	String amount ;
	Currency currency ;
	String statistic ;  
	String cdate ;  
	String creator_info_user_id ;

}
