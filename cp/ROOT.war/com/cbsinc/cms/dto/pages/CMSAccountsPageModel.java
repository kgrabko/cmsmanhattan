package com.cbsinc.cms.dto.pages;

import java.util.List;

public class CMSAccountsPageModel {
	
	
	

}
