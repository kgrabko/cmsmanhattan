package com.cbsinc.cms.dto.pages;

public class CMSAccountHistoryPageModel {

}
