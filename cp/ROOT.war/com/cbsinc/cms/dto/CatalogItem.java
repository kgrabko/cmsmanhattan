package com.cbsinc.cms.dto;

public class CatalogItem {
	
	String selected;
	String item;
	String code ;
	String url ;
	String subcatalogItem;
	String subitem;
	String subcode;
	String suburl;

}
