package com.cbsinc.cms.dto;

public class YearFromItem {
	
	String selected;
	String item;
	String code ;
	String url ;

}
