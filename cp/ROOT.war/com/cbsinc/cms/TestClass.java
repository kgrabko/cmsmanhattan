package com.cbsinc.cms;

import java.io.Serializable;

public class TestClass implements Serializable {

	/**
	 * 
	 */
	public TestClass() {

		super();
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = -5294701214214941520L;

}
